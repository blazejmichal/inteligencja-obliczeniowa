from tasksLab5.Lab5Task3 import Lab5Task3


def main():
    Lab5Task3.run()


if __name__ == '__main__':
    main()
