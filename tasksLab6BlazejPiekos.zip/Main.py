from tasksLab6.Lab6Task1 import Lab6Task1
from tasksLab6.Lab6Task2 import Lab6Task2
from tasksLab6.Lab6Task3 import Lab6Task3


def main():
    print("lab6")
    Lab6Task1.run()
    Lab6Task2.run()
    Lab6Task3.run()


if __name__ == '__main__':
    main()
