from tasksLab4.Lab4Task1ABC import Lab4Task1ABC
from tasksLab4.Lab4Task2 import Lab4Task2


def main():
    Lab4Task1ABC.run()
    Lab4Task2.run()


if __name__ == '__main__':
    main()
